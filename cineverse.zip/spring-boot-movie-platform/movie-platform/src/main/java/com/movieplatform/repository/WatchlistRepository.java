package com.movieplatform.repository;

import com.movieplatform.model.WatchlistItem;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WatchlistRepository extends MongoRepository<WatchlistItem, String> {

    List<WatchlistItem> findByUserId(String userId);

    List<WatchlistItem> findByUserIdOrderByAddedAtDesc(String userId);

    Optional<WatchlistItem> findByUserIdAndImdbId(String userId, String imdbId);

    boolean existsByUserIdAndImdbId(String userId, String imdbId);

    void deleteByUserIdAndImdbId(String userId, String imdbId);

    long countByUserId(String userId);
}
