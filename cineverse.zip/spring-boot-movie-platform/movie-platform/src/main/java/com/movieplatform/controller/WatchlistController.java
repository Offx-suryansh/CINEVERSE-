package com.movieplatform.controller;

import com.movieplatform.dto.WatchlistRequest;
import com.movieplatform.model.WatchlistItem;
import com.movieplatform.security.CustomUserDetails;
import com.movieplatform.service.WatchlistService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/watchlist")
@RequiredArgsConstructor
@Slf4j
public class WatchlistController {

    private final WatchlistService watchlistService;

    @GetMapping
    public String viewWatchlist(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        List<WatchlistItem> watchlist = watchlistService.getUserWatchlist(userDetails.getId());
        model.addAttribute("watchlist", watchlist);
        model.addAttribute("watchlistCount", watchlist.size());
        return "watchlist/watchlist";
    }

    @PostMapping("/add")
    @ResponseBody
    public ResponseEntity<?> addToWatchlist(@RequestBody @Valid WatchlistRequest request,
                                            @AuthenticationPrincipal CustomUserDetails userDetails) {
        try {
            WatchlistItem item = watchlistService.addToWatchlist(
                    userDetails.getId(), userDetails.getUsername(), request);
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Added to watchlist!",
                    "itemId", item.getId()
            ));
        } catch (Exception e) {
            log.error("Error adding to watchlist: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/remove/{imdbId}")
    @ResponseBody
    public ResponseEntity<?> removeFromWatchlist(@PathVariable String imdbId,
                                                 @AuthenticationPrincipal CustomUserDetails userDetails) {
        try {
            watchlistService.removeFromWatchlist(
                    userDetails.getId(), userDetails.getUsername(), imdbId);
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Removed from watchlist!"
            ));
        } catch (Exception e) {
            log.error("Error removing from watchlist: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/remove-form/{imdbId}")
    public String removeFromWatchlistForm(@PathVariable String imdbId,
                                          @AuthenticationPrincipal CustomUserDetails userDetails,
                                          RedirectAttributes redirectAttributes) {
        try {
            watchlistService.removeFromWatchlist(
                    userDetails.getId(), userDetails.getUsername(), imdbId);
            redirectAttributes.addFlashAttribute("successMessage", "Movie removed from watchlist.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to remove movie.");
        }
        return "redirect:/watchlist";
    }
}
