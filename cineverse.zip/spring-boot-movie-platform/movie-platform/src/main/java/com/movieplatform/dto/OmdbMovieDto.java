package com.movieplatform.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OmdbMovieDto {

    @JsonAlias("imdbID")
    private String imdbId;

    @JsonAlias("Title")
    private String title;

    @JsonAlias("Year")
    private String year;

    @JsonAlias("Rated")
    private String rated;

    @JsonAlias("Released")
    private String released;

    @JsonAlias("Runtime")
    private String runtime;

    @JsonAlias("Genre")
    private String genre;

    @JsonAlias("Director")
    private String director;

    @JsonAlias("Writer")
    private String writer;

    @JsonAlias("Actors")
    private String actors;

    @JsonAlias("Plot")
    private String plot;

    @JsonAlias("Language")
    private String language;

    @JsonAlias("Country")
    private String country;

    @JsonAlias("Awards")
    private String awards;

    @JsonAlias("Poster")
    private String poster;

    @JsonAlias("Ratings")
    private List<OmdbRatingDto> ratings;

    @JsonAlias("imdbRating")
    private String imdbRating;

    @JsonAlias("imdbVotes")
    private String imdbVotes;

    @JsonAlias("Type")
    private String type;

    @JsonAlias("DVD")
    private String dvd;

    @JsonAlias("BoxOffice")
    private String boxOffice;

    @JsonAlias("Production")
    private String production;

    @JsonAlias("Website")
    private String website;

    @JsonAlias("Response")
    private String response;

    @JsonAlias("Error")
    private String error;

    public boolean isValidPoster() {
        return poster != null && !poster.isBlank() && !poster.equalsIgnoreCase("N/A");
    }

    public String getSafePoster() {
        return isValidPoster() ? poster : "/images/no-poster.png";
    }

    public double getImdbRatingAsDouble() {
        try {
            if (imdbRating != null && !imdbRating.equalsIgnoreCase("N/A")) {
                return Double.parseDouble(imdbRating);
            }
        } catch (NumberFormatException ignored) {}
        return 0.0;
    }
}
