package com.movieplatform.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WatchlistRequest {

    @NotBlank(message = "IMDb ID is required")
    private String imdbId;

    private String title;

    private String year;

    private String genre;

    private String poster;

    private String imdbRating;

    private String director;
}
