package com.movieplatform.controller;

import com.movieplatform.dto.OmdbMovieDto;
import com.movieplatform.dto.RatingRequest;
import com.movieplatform.exception.ResourceNotFoundException;
import com.movieplatform.model.Rating;
import com.movieplatform.model.WatchlistItem;
import com.movieplatform.security.CustomUserDetails;
import com.movieplatform.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/movies")
@RequiredArgsConstructor
@Slf4j
public class MovieController {

    private final OmdbService omdbService;
    private final UserService userService;
    private final WatchlistService watchlistService;
    private final RatingService ratingService;

    @GetMapping("/search")
    public String searchMovies(@RequestParam(required = false) String query,
                               @AuthenticationPrincipal CustomUserDetails userDetails,
                               Model model) {
        model.addAttribute("query", query);

        if (query != null && !query.isBlank()) {
            try {
                List<OmdbMovieDto> results = omdbService.searchMovies(query.trim());
                model.addAttribute("results", results);
                model.addAttribute("resultCount", results.size());
                userService.addSearchHistory(userDetails.getUsername(), query.trim());

                if (results.isEmpty()) {
                    model.addAttribute("noResults", true);
                }
            } catch (Exception e) {
                log.error("Error searching movies: {}", e.getMessage());
                model.addAttribute("errorMessage", "Failed to search movies. Please try again.");
            }
        }

        return "movie/search";
    }

    @GetMapping("/{imdbId}")
    public String movieDetails(@PathVariable String imdbId,
                               @AuthenticationPrincipal CustomUserDetails userDetails,
                               Model model) {
        OmdbMovieDto movie = omdbService.getMovieByImdbId(imdbId);
        if (movie == null) {
            throw new ResourceNotFoundException("Movie not found with IMDb ID: " + imdbId);
        }

        String userId = userDetails.getId();

        boolean inWatchlist = watchlistService.isInWatchlist(userId, imdbId);
        Optional<Rating> userRating = ratingService.getUserRatingForMovie(userId, imdbId);
        List<Rating> allRatings = ratingService.getMovieRatings(imdbId);
        double avgRating = ratingService.getAverageRating(imdbId);

        model.addAttribute("movie", movie);
        model.addAttribute("inWatchlist", inWatchlist);
        model.addAttribute("userRating", userRating.orElse(null));
        model.addAttribute("allRatings", allRatings);
        model.addAttribute("avgRating", String.format("%.1f", avgRating));
        model.addAttribute("ratingCount", allRatings.size());
        model.addAttribute("ratingRequest", new RatingRequest());

        return "movie/details";
    }

    @PostMapping("/{imdbId}/rate")
    public String rateMovie(@PathVariable String imdbId,
                            @Valid @ModelAttribute("ratingRequest") RatingRequest request,
                            BindingResult bindingResult,
                            @AuthenticationPrincipal CustomUserDetails userDetails,
                            RedirectAttributes redirectAttributes,
                            Model model) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("ratingError", "Invalid rating. Please provide 1-5 stars.");
            return "redirect:/movies/" + imdbId;
        }

        try {
            request.setImdbId(imdbId);
            ratingService.saveRating(userDetails.getId(), userDetails.getUsername(), request);
            redirectAttributes.addFlashAttribute("successMessage", "Your rating has been saved!");
        } catch (Exception e) {
            log.error("Error saving rating: {}", e.getMessage());
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to save rating. Please try again.");
        }

        return "redirect:/movies/" + imdbId;
    }

    @PostMapping("/ratings/{ratingId}/delete")
    public String deleteRating(@PathVariable String ratingId,
                               @AuthenticationPrincipal CustomUserDetails userDetails,
                               RedirectAttributes redirectAttributes) {
        try {
            ratingService.deleteRating(ratingId, userDetails.getId());
            redirectAttributes.addFlashAttribute("successMessage", "Rating deleted successfully.");
        } catch (Exception e) {
            log.error("Error deleting rating: {}", e.getMessage());
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to delete rating.");
        }
        return "redirect:/profile/ratings";
    }
}
