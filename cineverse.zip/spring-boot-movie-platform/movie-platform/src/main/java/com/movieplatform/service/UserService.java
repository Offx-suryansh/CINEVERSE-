package com.movieplatform.service;

import com.movieplatform.dto.ProfileUpdateRequest;
import com.movieplatform.dto.RegisterRequest;
import com.movieplatform.exception.DuplicateResourceException;
import com.movieplatform.exception.ResourceNotFoundException;
import com.movieplatform.exception.ValidationException;
import com.movieplatform.model.SearchHistory;
import com.movieplatform.model.User;
import com.movieplatform.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.dao.DataAccessResourceFailureException;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserRepository userRepository;
    private final InMemoryUserStore inMemoryUserStore;
    private final PasswordEncoder passwordEncoder;

    public User registerUser(RegisterRequest request) {
        log.info("Registering new user: {}", request.getUsername());

        if (!request.getPassword().equals(request.getConfirmPassword())) {
            throw new ValidationException("Passwords do not match");
        }
        if (userExistsByUsername(request.getUsername())) {
            throw new DuplicateResourceException("Username '" + request.getUsername() + "' is already taken");
        }
        if (userExistsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email '" + request.getEmail() + "' is already registered");
        }

        User user = User.builder()
                .fullName(request.getFullName())
                .username(request.getUsername().toLowerCase().trim())
                .email(request.getEmail().toLowerCase().trim())
                .password(passwordEncoder.encode(request.getPassword()))
                .build();

        User saved = saveUser(user);
        log.info("User registered successfully: {}", saved.getUsername());
        return saved;
    }

    public User findByUsername(String username) {
        return findUserByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
    }

    public User findById(String id) {
        return findUserById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    public User updateProfile(String username, ProfileUpdateRequest request) {
        User user = findByUsername(username);

        // Check email uniqueness if changed
        if (!user.getEmail().equalsIgnoreCase(request.getEmail())) {
            if (userExistsByEmail(request.getEmail())) {
                throw new DuplicateResourceException("Email '" + request.getEmail() + "' is already in use");
            }
            user.setEmail(request.getEmail().toLowerCase().trim());
        }

        user.setFullName(request.getFullName());
        user.setBio(request.getBio());

        // Change password if provided
        if (request.getNewPassword() != null && !request.getNewPassword().isBlank()) {
            if (request.getCurrentPassword() == null || request.getCurrentPassword().isBlank()) {
                throw new ValidationException("Current password is required to set a new password");
            }
            if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
                throw new ValidationException("Current password is incorrect");
            }
            if (!request.getNewPassword().equals(request.getConfirmNewPassword())) {
                throw new ValidationException("New passwords do not match");
            }
            user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        }

        return saveUser(user);
    }

    public void addSearchHistory(String username, String query) {
        if (query == null || query.isBlank()) return;
        findUserByUsername(username).ifPresent(user -> {
            List<SearchHistory> history = user.getSearchHistory();
            if (history == null) {
                history = new ArrayList<>();
            }
            // Remove duplicate
            history.removeIf(h -> h.getQuery().equalsIgnoreCase(query.trim()));
            // Add to front
            history.add(0, SearchHistory.of(query.trim()));
            // Keep last 20
            if (history.size() > 20) {
                history = new ArrayList<>(history.subList(0, 20));
            }
            user.setSearchHistory(history);
            saveUser(user);
        });
    }

    public void clearSearchHistory(String username) {
        findUserByUsername(username).ifPresent(user -> {
            user.setSearchHistory(new ArrayList<>());
            saveUser(user);
        });
    }

    public void addToWatchlistIds(String username, String imdbId) {
        findUserByUsername(username).ifPresent(user -> {
            if (!user.getWatchlistImdbIds().contains(imdbId)) {
                user.getWatchlistImdbIds().add(imdbId);
                saveUser(user);
            }
        });
    }

    public void removeFromWatchlistIds(String username, String imdbId) {
        findUserByUsername(username).ifPresent(user -> {
            user.getWatchlistImdbIds().remove(imdbId);
            saveUser(user);
        });
    }

    private boolean userExistsByUsername(String username) {
        try {
            return userRepository.existsByUsername(username) || inMemoryUserStore.existsByUsername(username);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, falling back to in-memory user lookup for username check", ex);
            return inMemoryUserStore.existsByUsername(username);
        }
    }

    private boolean userExistsByEmail(String email) {
        try {
            return userRepository.existsByEmail(email) || inMemoryUserStore.existsByEmail(email);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, falling back to in-memory user lookup for email check", ex);
            return inMemoryUserStore.existsByEmail(email);
        }
    }

    private java.util.Optional<User> findUserByUsername(String username) {
        try {
            return userRepository.findByUsername(username).or(() -> inMemoryUserStore.findByUsername(username));
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, falling back to in-memory user lookup", ex);
            return inMemoryUserStore.findByUsername(username);
        }
    }

    private java.util.Optional<User> findUserById(String id) {
        try {
            return userRepository.findById(id).or(() -> inMemoryUserStore.findById(id));
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, falling back to in-memory user lookup", ex);
            return inMemoryUserStore.findById(id);
        }
    }

    private User saveUser(User user) {
        try {
            return userRepository.save(user);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, saving user in memory instead", ex);
            return inMemoryUserStore.save(user);
        }
    }
}
