package com.movieplatform.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RatingRequest {

    @NotBlank(message = "Movie IMDb ID is required")
    private String imdbId;

    @NotBlank(message = "Movie title is required")
    private String movieTitle;

    private String posterUrl;

    @Min(value = 1, message = "Rating must be at least 1 star")
    @Max(value = 5, message = "Rating cannot exceed 5 stars")
    private int stars;

    @Size(max = 1000, message = "Review cannot exceed 1000 characters")
    private String review;
}
