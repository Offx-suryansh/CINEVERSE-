package com.movieplatform.service;

import com.movieplatform.dto.WatchlistRequest;
import com.movieplatform.exception.DuplicateResourceException;
import com.movieplatform.model.WatchlistItem;
import com.movieplatform.repository.WatchlistRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class WatchlistService {

    private final WatchlistRepository watchlistRepository;
    private final InMemoryContentStore inMemoryContentStore;
    private final UserService userService;

    public WatchlistItem addToWatchlist(String userId, String username, WatchlistRequest request) {
        if (isInWatchlist(userId, request.getImdbId())) {
            throw new DuplicateResourceException("Movie is already in your watchlist");
        }

        WatchlistItem item = WatchlistItem.builder()
                .userId(userId)
                .imdbId(request.getImdbId())
                .title(request.getTitle())
                .year(request.getYear())
                .genre(request.getGenre())
                .poster(request.getPoster())
                .imdbRating(request.getImdbRating())
                .director(request.getDirector())
                .build();

        WatchlistItem saved;
        try {
            saved = watchlistRepository.save(item);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, saving to in-memory watchlist", ex);
            saved = inMemoryContentStore.saveWatchlistItem(item);
        }
        userService.addToWatchlistIds(username, request.getImdbId());
        log.info("Added movie {} to watchlist for user {}", request.getImdbId(), userId);
        return saved;
    }

    public void removeFromWatchlist(String userId, String username, String imdbId) {
        try {
            watchlistRepository.deleteByUserIdAndImdbId(userId, imdbId);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, deleting from in-memory watchlist", ex);
            inMemoryContentStore.deleteWatchlistItem(userId, imdbId);
        }
        userService.removeFromWatchlistIds(username, imdbId);
        log.info("Removed movie {} from watchlist for user {}", imdbId, userId);
    }

    public List<WatchlistItem> getUserWatchlist(String userId) {
        try {
            return watchlistRepository.findByUserIdOrderByAddedAtDesc(userId);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, using in-memory watchlist", ex);
            return inMemoryContentStore.findWatchlistByUserId(userId);
        }
    }

    public boolean isInWatchlist(String userId, String imdbId) {
        try {
            return watchlistRepository.existsByUserIdAndImdbId(userId, imdbId);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, using in-memory watchlist state", ex);
            return inMemoryContentStore.existsWatchlist(userId, imdbId);
        }
    }

    public Optional<WatchlistItem> findByUserIdAndImdbId(String userId, String imdbId) {
        try {
            return watchlistRepository.findByUserIdAndImdbId(userId, imdbId);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, using in-memory watchlist state", ex);
            return inMemoryContentStore.findWatchlistByUserIdAndImdbId(userId, imdbId);
        }
    }

    public long getWatchlistCount(String userId) {
        try {
            return watchlistRepository.countByUserId(userId);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, using in-memory watchlist count", ex);
            return inMemoryContentStore.countWatchlistByUserId(userId);
        }
    }
}
