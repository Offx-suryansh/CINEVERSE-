package com.movieplatform.service;

import com.movieplatform.dto.OmdbMovieDto;
import com.movieplatform.model.Rating;
import com.movieplatform.model.WatchlistItem;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class RecommendationService {

    private final WatchlistService watchlistService;
    private final RatingService ratingService;
    private final OmdbService omdbService;

    private static final List<String> POPULAR_GENRES = List.of(
            "Action", "Comedy", "Drama", "Thriller", "Sci-Fi",
            "Romance", "Horror", "Adventure", "Animation", "Mystery"
    );

    private static final List<String> FALLBACK_MOVIES = List.of(
            "The Dark Knight", "Inception", "Interstellar", "The Godfather",
            "Forrest Gump", "The Shawshank Redemption", "Pulp Fiction",
            "The Matrix", "Goodfellas", "Fight Club", "Avengers",
            "Jurassic Park", "Titanic", "The Lion King", "Gladiator"
    );

    public List<OmdbMovieDto> getRecommendations(String userId) {
        log.debug("Generating recommendations for user: {}", userId);

        List<OmdbMovieDto> recommendations = new ArrayList<>();
        Set<String> addedImdbIds = new HashSet<>();

        // Collect user's watchlist
        List<WatchlistItem> watchlist = watchlistService.getUserWatchlist(userId);
        Set<String> watchlistIds = watchlist.stream()
                .map(WatchlistItem::getImdbId)
                .collect(Collectors.toSet());
        addedImdbIds.addAll(watchlistIds);

        // Get top-rated genres from user's ratings
        List<Rating> userRatings = ratingService.getUserRatings(userId);
        List<String> topRatedGenres = getTopRatedGenres(userRatings);

        // Get top genres from watchlist
        List<String> watchlistGenres = getWatchlistGenres(watchlist);

        // Merge and deduplicate genres
        Set<String> preferredGenres = new LinkedHashSet<>();
        preferredGenres.addAll(topRatedGenres);
        preferredGenres.addAll(watchlistGenres);

        // If user has no data, use popular genres
        if (preferredGenres.isEmpty()) {
            preferredGenres.addAll(POPULAR_GENRES.subList(0, 5));
        }

        // Fetch movies based on preferred genres
        for (String genre : preferredGenres) {
            if (recommendations.size() >= 12) break;
            try {
                List<OmdbMovieDto> genreMovies = omdbService.searchMovies(genre);
                for (OmdbMovieDto movie : genreMovies) {
                    if (recommendations.size() >= 12) break;
                    if (!addedImdbIds.contains(movie.getImdbId()) && movie.getImdbId() != null) {
                        // Filter by good IMDb rating
                        recommendations.add(movie);
                        addedImdbIds.add(movie.getImdbId());
                    }
                }
            } catch (Exception e) {
                log.warn("Error fetching genre recommendations for {}: {}", genre, e.getMessage());
            }
        }

        // If not enough recommendations, add fallback popular movies
        if (recommendations.size() < 8) {
            for (String title : FALLBACK_MOVIES) {
                if (recommendations.size() >= 12) break;
                try {
                    OmdbMovieDto movie = omdbService.getMovieByTitle(title);
                    if (movie != null && !addedImdbIds.contains(movie.getImdbId())) {
                        recommendations.add(movie);
                        addedImdbIds.add(movie.getImdbId());
                    }
                } catch (Exception e) {
                    log.warn("Error fetching fallback movie {}: {}", title, e.getMessage());
                }
            }
        }

        log.debug("Generated {} recommendations for user: {}", recommendations.size(), userId);
        return recommendations;
    }

    private List<String> getTopRatedGenres(List<Rating> ratings) {
        if (ratings == null || ratings.isEmpty()) return Collections.emptyList();

        // Get genres from highly rated movies (4-5 stars)
        Map<String, Integer> genreCount = new HashMap<>();

        ratings.stream()
                .filter(r -> r.getStars() >= 4)
                .forEach(r -> {
                    try {
                        OmdbMovieDto movie = omdbService.getMovieByImdbId(r.getImdbId());
                        if (movie != null && movie.getGenre() != null) {
                            String[] genres = movie.getGenre().split(",\\s*");
                            for (String genre : genres) {
                                genreCount.merge(genre.trim(), 1, Integer::sum);
                            }
                        }
                    } catch (Exception ignored) {}
                });

        return genreCount.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(5)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    private List<String> getWatchlistGenres(List<WatchlistItem> watchlist) {
        if (watchlist == null || watchlist.isEmpty()) return Collections.emptyList();

        Map<String, Integer> genreCount = new HashMap<>();
        for (WatchlistItem item : watchlist) {
            if (item.getGenre() != null && !item.getGenre().isBlank()) {
                String[] genres = item.getGenre().split(",\\s*");
                for (String genre : genres) {
                    genreCount.merge(genre.trim(), 1, Integer::sum);
                }
            }
        }

        return genreCount.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(5)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }
}
