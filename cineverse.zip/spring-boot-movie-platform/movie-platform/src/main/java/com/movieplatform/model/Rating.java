package com.movieplatform.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "ratings")
@CompoundIndexes({
        @CompoundIndex(name = "user_movie_idx", def = "{'userId': 1, 'imdbId': 1}", unique = true)
})
public class Rating {

    @Id
    private String id;

    private String userId;

    private String username;

    private String imdbId;

    private String movieTitle;

    private String posterUrl;

    private int stars; // 1-5

    private String review;

    @CreatedDate
    private LocalDateTime createdAt;

    @LastModifiedDate
    private LocalDateTime updatedAt;
}
