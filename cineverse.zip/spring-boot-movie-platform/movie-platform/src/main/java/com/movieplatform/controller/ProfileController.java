package com.movieplatform.controller;

import com.movieplatform.dto.ProfileUpdateRequest;
import com.movieplatform.exception.DuplicateResourceException;
import com.movieplatform.exception.ValidationException;
import com.movieplatform.model.Rating;
import com.movieplatform.model.User;
import com.movieplatform.security.CustomUserDetails;
import com.movieplatform.service.RatingService;
import com.movieplatform.service.UserService;
import com.movieplatform.service.WatchlistService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/profile")
@RequiredArgsConstructor
@Slf4j
public class ProfileController {

    private final UserService userService;
    private final RatingService ratingService;
    private final WatchlistService watchlistService;

    @GetMapping
    public String profilePage(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername());
        long watchlistCount = watchlistService.getWatchlistCount(userDetails.getId());
        long ratingCount = ratingService.getRatingCount(userDetails.getId());

        ProfileUpdateRequest updateRequest = ProfileUpdateRequest.builder()
                .fullName(user.getFullName())
                .email(user.getEmail())
                .bio(user.getBio())
                .build();

        model.addAttribute("user", user);
        model.addAttribute("profileUpdateRequest", updateRequest);
        model.addAttribute("watchlistCount", watchlistCount);
        model.addAttribute("ratingCount", ratingCount);

        return "profile/profile";
    }

    @PostMapping("/update")
    public String updateProfile(@Valid @ModelAttribute("profileUpdateRequest") ProfileUpdateRequest request,
                                BindingResult bindingResult,
                                @AuthenticationPrincipal CustomUserDetails userDetails,
                                Model model,
                                RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            User user = userService.findByUsername(userDetails.getUsername());
            model.addAttribute("user", user);
            model.addAttribute("watchlistCount", watchlistService.getWatchlistCount(userDetails.getId()));
            model.addAttribute("ratingCount", ratingService.getRatingCount(userDetails.getId()));
            return "profile/profile";
        }

        try {
            userService.updateProfile(userDetails.getUsername(), request);
            redirectAttributes.addFlashAttribute("successMessage", "Profile updated successfully!");
        } catch (DuplicateResourceException | ValidationException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }

        return "redirect:/profile";
    }

    @GetMapping("/ratings")
    public String myRatings(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        List<Rating> ratings = ratingService.getUserRatings(userDetails.getId());
        model.addAttribute("ratings", ratings);
        model.addAttribute("ratingCount", ratings.size());
        return "profile/ratings";
    }

    @GetMapping("/history")
    public String searchHistory(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername());
        model.addAttribute("searchHistory", user.getSearchHistory());
        return "profile/history";
    }

    @PostMapping("/history/clear")
    public String clearHistory(@AuthenticationPrincipal CustomUserDetails userDetails,
                               RedirectAttributes redirectAttributes) {
        userService.clearSearchHistory(userDetails.getUsername());
        redirectAttributes.addFlashAttribute("successMessage", "Search history cleared.");
        return "redirect:/profile/history";
    }
}
