package com.movieplatform.service;

import com.movieplatform.model.User;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class InMemoryUserStore {

    private final Map<String, User> usersByUsername = new ConcurrentHashMap<>();
    private final Map<String, User> usersByEmail = new ConcurrentHashMap<>();
    private final Map<String, User> usersById = new ConcurrentHashMap<>();

    @PostConstruct
    public void seedDefaultAdminUser() {
        if (!existsByUsername("admin")) {
            User admin = User.builder()
                    .id(UUID.randomUUID().toString())
                    .username("admin")
                    .email("admin@example.com")
                    .password("$2a$12$zM1A0Rz5uXK8kQkYQ8YwKOwI0v6xZJh2l4m2C9t2v3u4g5h6i7j8K")
                    .fullName("Administrator")
                    .roles(new ArrayList<>(List.of("ROLE_USER", "ROLE_ADMIN")))
                    .enabled(true)
                    .build();
            save(admin);
        }
    }

    public User save(User user) {
        if (user.getId() == null || user.getId().isBlank()) {
            user.setId(UUID.randomUUID().toString());
        }

        String normalizedUsername = normalize(user.getUsername());
        String normalizedEmail = normalize(user.getEmail());

        usersByUsername.put(normalizedUsername, user);
        if (normalizedEmail != null) {
            usersByEmail.put(normalizedEmail, user);
        }
        usersById.put(user.getId(), user);
        return user;
    }

    public Optional<User> findByUsername(String username) {
        if (username == null || username.isBlank()) {
            return Optional.empty();
        }
        return Optional.ofNullable(usersByUsername.get(normalize(username)));
    }

    public Optional<User> findByEmail(String email) {
        if (email == null || email.isBlank()) {
            return Optional.empty();
        }
        return Optional.ofNullable(usersByEmail.get(normalize(email)));
    }

    public Optional<User> findById(String id) {
        if (id == null || id.isBlank()) {
            return Optional.empty();
        }
        return Optional.ofNullable(usersById.get(id));
    }

    public boolean existsByUsername(String username) {
        return findByUsername(username).isPresent();
    }

    public boolean existsByEmail(String email) {
        return findByEmail(email).isPresent();
    }

    private String normalize(String value) {
        if (value == null) {
            return null;
        }
        return value.toLowerCase(Locale.ROOT).trim();
    }
}
