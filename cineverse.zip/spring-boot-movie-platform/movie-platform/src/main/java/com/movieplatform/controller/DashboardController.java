package com.movieplatform.controller;

import com.movieplatform.dto.OmdbMovieDto;
import com.movieplatform.model.Rating;
import com.movieplatform.model.User;
import com.movieplatform.model.WatchlistItem;
import com.movieplatform.security.CustomUserDetails;
import com.movieplatform.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/dashboard")
@RequiredArgsConstructor
@Slf4j
public class DashboardController {

    private final UserService userService;
    private final WatchlistService watchlistService;
    private final RatingService ratingService;
    private final RecommendationService recommendationService;

    @GetMapping
    public String dashboard(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        String userId = userDetails.getId();
        String username = userDetails.getUsername();

        User user = userService.findByUsername(username);

        List<WatchlistItem> watchlist = watchlistService.getUserWatchlist(userId);
        List<Rating> recentRatings = ratingService.getUserRatings(userId);
        long watchlistCount = watchlistService.getWatchlistCount(userId);
        long ratingCount = ratingService.getRatingCount(userId);

        // Get recommendations (limit to 8 for dashboard)
        List<OmdbMovieDto> recommendations;
        try {
            recommendations = recommendationService.getRecommendations(userId);
            if (recommendations.size() > 8) {
                recommendations = recommendations.subList(0, 8);
            }
        } catch (Exception e) {
            log.warn("Could not load recommendations: {}", e.getMessage());
            recommendations = List.of();
        }

        model.addAttribute("user", user);
        model.addAttribute("watchlist", watchlist.stream().limit(5).toList());
        model.addAttribute("recentRatings", recentRatings.stream().limit(5).toList());
        model.addAttribute("watchlistCount", watchlistCount);
        model.addAttribute("ratingCount", ratingCount);
        model.addAttribute("recommendations", recommendations);
        model.addAttribute("searchHistory", user.getSearchHistory().stream().limit(5).toList());

        return "dashboard/dashboard";
    }
}
