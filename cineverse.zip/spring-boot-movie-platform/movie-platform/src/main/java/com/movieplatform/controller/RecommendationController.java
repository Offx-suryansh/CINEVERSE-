package com.movieplatform.controller;

import com.movieplatform.dto.OmdbMovieDto;
import com.movieplatform.security.CustomUserDetails;
import com.movieplatform.service.RecommendationService;
import com.movieplatform.service.WatchlistService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/recommendations")
@RequiredArgsConstructor
@Slf4j
public class RecommendationController {

    private final RecommendationService recommendationService;
    private final WatchlistService watchlistService;

    @GetMapping
    public String recommendations(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        String userId = userDetails.getId();

        List<OmdbMovieDto> recommendations;
        try {
            recommendations = recommendationService.getRecommendations(userId);
        } catch (Exception e) {
            log.error("Error generating recommendations: {}", e.getMessage());
            recommendations = List.of();
            model.addAttribute("errorMessage", "Unable to load recommendations at this time.");
        }

        // Get watchlist IDs for in-watchlist check
        List<String> watchlistIds = watchlistService.getUserWatchlist(userId)
                .stream().map(w -> w.getImdbId()).toList();

        model.addAttribute("recommendations", recommendations);
        model.addAttribute("watchlistIds", watchlistIds);
        model.addAttribute("recommendationCount", recommendations.size());

        return "movie/recommendations";
    }
}
