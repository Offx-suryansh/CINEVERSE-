package com.movieplatform.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "watchlist")
@CompoundIndexes({
        @CompoundIndex(name = "user_movie_watchlist_idx", def = "{'userId': 1, 'imdbId': 1}", unique = true)
})
public class WatchlistItem {

    @Id
    private String id;

    private String userId;

    private String imdbId;

    private String title;

    private String year;

    private String genre;

    private String poster;

    private String imdbRating;

    private String director;

    @CreatedDate
    private LocalDateTime addedAt;
}
