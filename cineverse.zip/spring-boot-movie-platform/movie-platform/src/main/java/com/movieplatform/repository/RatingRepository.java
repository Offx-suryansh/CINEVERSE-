package com.movieplatform.repository;

import com.movieplatform.model.Rating;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RatingRepository extends MongoRepository<Rating, String> {

    List<Rating> findByUserId(String userId);

    Optional<Rating> findByUserIdAndImdbId(String userId, String imdbId);

    List<Rating> findByImdbId(String imdbId);

    boolean existsByUserIdAndImdbId(String userId, String imdbId);

    void deleteByUserIdAndImdbId(String userId, String imdbId);

    List<Rating> findByUserIdOrderByUpdatedAtDesc(String userId);

    long countByImdbId(String imdbId);
}
