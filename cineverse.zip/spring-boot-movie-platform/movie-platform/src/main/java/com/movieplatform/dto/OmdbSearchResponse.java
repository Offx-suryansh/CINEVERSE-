package com.movieplatform.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OmdbSearchResponse {

    @JsonAlias("Search")
    private List<OmdbMovieDto> search;

    @JsonAlias("totalResults")
    private String totalResults;

    @JsonAlias("Response")
    private String response;

    @JsonAlias("Error")
    private String error;

    public boolean isSuccess() {
        return "True".equalsIgnoreCase(response);
    }
}
