package com.movieplatform.service;

import com.movieplatform.dto.RatingRequest;
import com.movieplatform.exception.ResourceNotFoundException;
import com.movieplatform.exception.UnauthorizedException;
import com.movieplatform.model.Rating;
import com.movieplatform.repository.RatingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class RatingService {

    private final RatingRepository ratingRepository;
    private final InMemoryContentStore inMemoryContentStore;

    public Rating saveRating(String userId, String username, RatingRequest request) {
        Optional<Rating> existing;
        try {
            existing = ratingRepository.findByUserIdAndImdbId(userId, request.getImdbId());
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, checking in-memory rating", ex);
            existing = inMemoryContentStore.findRatingByUserIdAndImdbId(userId, request.getImdbId());
        }

        Rating rating;
        if (existing.isPresent()) {
            rating = existing.get();
            rating.setStars(request.getStars());
            rating.setReview(request.getReview());
            rating.setMovieTitle(request.getMovieTitle());
            rating.setPosterUrl(request.getPosterUrl());
        } else {
            rating = Rating.builder()
                    .userId(userId)
                    .username(username)
                    .imdbId(request.getImdbId())
                    .movieTitle(request.getMovieTitle())
                    .posterUrl(request.getPosterUrl())
                    .stars(request.getStars())
                    .review(request.getReview())
                    .build();
        }

        Rating saved;
        try {
            saved = ratingRepository.save(rating);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, saving rating to in-memory store", ex);
            saved = inMemoryContentStore.saveRating(rating);
        }
        log.info("Rating saved for movie {} by user {}", request.getImdbId(), userId);
        return saved;
    }

    public List<Rating> getUserRatings(String userId) {
        try {
            return ratingRepository.findByUserIdOrderByUpdatedAtDesc(userId);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, loading ratings from in-memory store", ex);
            return inMemoryContentStore.findRatingsByUserId(userId);
        }
    }

    public Optional<Rating> getUserRatingForMovie(String userId, String imdbId) {
        try {
            return ratingRepository.findByUserIdAndImdbId(userId, imdbId);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, checking in-memory rating", ex);
            return inMemoryContentStore.findRatingByUserIdAndImdbId(userId, imdbId);
        }
    }

    public Rating getRatingById(String ratingId) {
        try {
            Optional<Rating> result = ratingRepository.findById(ratingId);
            if (result.isPresent()) {
                return result.get();
            }
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, checking in-memory rating", ex);
            Optional<Rating> result = inMemoryContentStore.findRatingById(ratingId);
            if (result.isPresent()) {
                return result.get();
            }
        }
        throw new ResourceNotFoundException("Rating not found with id: " + ratingId);
    }

    public void deleteRating(String ratingId, String userId) {
        Rating rating = getRatingById(ratingId);
        if (!rating.getUserId().equals(userId)) {
            throw new UnauthorizedException("You are not authorized to delete this rating");
        }
        try {
            ratingRepository.deleteById(ratingId);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, deleting rating from in-memory store", ex);
            inMemoryContentStore.deleteRating(ratingId);
        }
        log.info("Rating {} deleted by user {}", ratingId, userId);
    }

    public void deleteRatingByImdbId(String userId, String imdbId) {
        try {
            ratingRepository.deleteByUserIdAndImdbId(userId, imdbId);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, deleting rating from in-memory store", ex);
            inMemoryContentStore.deleteRatingByUserIdAndImdbId(userId, imdbId);
        }
        log.info("Rating for movie {} deleted by user {}", imdbId, userId);
    }

    public List<Rating> getMovieRatings(String imdbId) {
        try {
            return ratingRepository.findByImdbId(imdbId);
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, loading movie ratings from in-memory store", ex);
            return inMemoryContentStore.findRatingsByImdbId(imdbId);
        }
    }

    public double getAverageRating(String imdbId) {
        List<Rating> ratings = getMovieRatings(imdbId);
        if (ratings.isEmpty()) return 0.0;
        return ratings.stream()
                .mapToInt(Rating::getStars)
                .average()
                .orElse(0.0);
    }

    public long getRatingCount(String userId) {
        try {
            return ratingRepository.findByUserId(userId).size();
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, getting rating count from in-memory store", ex);
            return inMemoryContentStore.countRatingsByUserId(userId);
        }
    }
}
