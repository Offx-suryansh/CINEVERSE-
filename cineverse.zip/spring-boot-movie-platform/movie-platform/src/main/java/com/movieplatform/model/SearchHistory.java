package com.movieplatform.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchHistory {

    private String query;
    private LocalDateTime searchedAt;

    public static SearchHistory of(String query) {
        return SearchHistory.builder()
                .query(query)
                .searchedAt(LocalDateTime.now())
                .build();
    }
}
