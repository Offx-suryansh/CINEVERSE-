package com.movieplatform.service;

import com.movieplatform.dto.OmdbMovieDto;
import com.movieplatform.dto.OmdbSearchResponse;
import com.movieplatform.exception.ExternalApiException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class OmdbService {

    private final RestTemplate restTemplate;

    @Value("${omdb.api.key}")
    private String apiKey;

    @Value("${omdb.api.base-url}")
    private String baseUrl;

    public List<OmdbMovieDto> searchMovies(String query) {
        log.debug("Searching movies with query: {}", query);
        try {
            String url = UriComponentsBuilder.fromHttpUrl(baseUrl)
                    .queryParam("apikey", apiKey)
                    .queryParam("s", query)
                    .queryParam("type", "movie")
                    .toUriString();

            OmdbSearchResponse response = restTemplate.getForObject(url, OmdbSearchResponse.class);

            if (response == null) {
                log.warn("Null response from OMDb API for query: {}", query);
                return Collections.emptyList();
            }
            if (!response.isSuccess()) {
                log.warn("OMDb API error: {}", response.getError());
                return Collections.emptyList();
            }
            return response.getSearch() != null ? response.getSearch() : Collections.emptyList();
        } catch (RestClientException e) {
            log.error("Error calling OMDb API: {}", e.getMessage());
            throw new ExternalApiException("Failed to connect to movie database. Please try again.");
        }
    }

    public OmdbMovieDto getMovieByImdbId(String imdbId) {
        log.debug("Fetching movie by IMDb ID: {}", imdbId);
        try {
            String url = UriComponentsBuilder.fromHttpUrl(baseUrl)
                    .queryParam("apikey", apiKey)
                    .queryParam("i", imdbId)
                    .queryParam("plot", "full")
                    .toUriString();

            OmdbMovieDto movie = restTemplate.getForObject(url, OmdbMovieDto.class);

            if (movie == null || !"True".equalsIgnoreCase(movie.getResponse())) {
                log.warn("Movie not found for IMDb ID: {}", imdbId);
                return null;
            }
            return movie;
        } catch (RestClientException e) {
            log.error("Error fetching movie details: {}", e.getMessage());
            throw new ExternalApiException("Failed to fetch movie details. Please try again.");
        }
    }

    public List<OmdbMovieDto> searchByGenre(String genre) {
        return searchMovies(genre);
    }

    public OmdbMovieDto getMovieByTitle(String title) {
        log.debug("Fetching movie by title: {}", title);
        try {
            String url = UriComponentsBuilder.fromHttpUrl(baseUrl)
                    .queryParam("apikey", apiKey)
                    .queryParam("t", title)
                    .queryParam("plot", "full")
                    .toUriString();

            OmdbMovieDto movie = restTemplate.getForObject(url, OmdbMovieDto.class);

            if (movie == null || !"True".equalsIgnoreCase(movie.getResponse())) {
                return null;
            }
            return movie;
        } catch (RestClientException e) {
            log.error("Error fetching movie by title: {}", e.getMessage());
            return null;
        }
    }
}
