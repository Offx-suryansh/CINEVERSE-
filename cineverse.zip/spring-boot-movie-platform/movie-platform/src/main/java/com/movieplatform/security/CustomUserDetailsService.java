package com.movieplatform.security;

import com.movieplatform.repository.UserRepository;
import com.movieplatform.service.InMemoryUserStore;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;
    private final InMemoryUserStore inMemoryUserStore;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        log.debug("Loading user by username: {}", username);
        try {
            return userRepository.findByUsername(username)
                    .map(CustomUserDetails::new)
                    .orElseGet(() -> inMemoryUserStore.findByUsername(username)
                            .map(CustomUserDetails::new)
                            .orElseThrow(() -> new UsernameNotFoundException(
                                    "User not found with username: " + username)));
        } catch (DataAccessResourceFailureException ex) {
            log.warn("MongoDB unavailable, loading user from in-memory store", ex);
            return inMemoryUserStore.findByUsername(username)
                    .map(CustomUserDetails::new)
                    .orElseThrow(() -> new UsernameNotFoundException(
                            "User not found with username: " + username));
        }
    }
}
