package com.movieplatform.service;

import com.movieplatform.model.Rating;
import com.movieplatform.model.WatchlistItem;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class InMemoryContentStore {

    private final Map<String, WatchlistItem> watchlistById = new ConcurrentHashMap<>();
    private final Map<String, List<WatchlistItem>> watchlistByUser = new ConcurrentHashMap<>();
    private final Map<String, Rating> ratingsById = new ConcurrentHashMap<>();
    private final Map<String, List<Rating>> ratingsByUser = new ConcurrentHashMap<>();
    private final Map<String, List<Rating>> ratingsByImdbId = new ConcurrentHashMap<>();

    public WatchlistItem saveWatchlistItem(WatchlistItem item) {
        if (item.getId() == null || item.getId().isBlank()) {
            item.setId(UUID.randomUUID().toString());
        }
        watchlistById.put(item.getId(), item);
        watchlistByUser.computeIfAbsent(item.getUserId(), key -> new ArrayList<>()).add(item);
        return item;
    }

    public void deleteWatchlistItem(String userId, String imdbId) {
        List<WatchlistItem> items = watchlistByUser.getOrDefault(userId, new ArrayList<>());
        items.removeIf(item -> imdbId.equals(item.getImdbId()));
        watchlistByUser.put(userId, items);
    }

    public List<WatchlistItem> findWatchlistByUserId(String userId) {
        return new ArrayList<>(watchlistByUser.getOrDefault(userId, List.of()));
    }

    public boolean existsWatchlist(String userId, String imdbId) {
        return watchlistByUser.getOrDefault(userId, List.of()).stream()
                .anyMatch(item -> imdbId.equals(item.getImdbId()));
    }

    public Optional<WatchlistItem> findWatchlistByUserIdAndImdbId(String userId, String imdbId) {
        return watchlistByUser.getOrDefault(userId, List.of()).stream()
                .filter(item -> imdbId.equals(item.getImdbId()))
                .findFirst();
    }

    public long countWatchlistByUserId(String userId) {
        return watchlistByUser.getOrDefault(userId, List.of()).size();
    }

    public Rating saveRating(Rating rating) {
        if (rating.getId() == null || rating.getId().isBlank()) {
            rating.setId(UUID.randomUUID().toString());
        }
        ratingsById.put(rating.getId(), rating);
        ratingsByUser.computeIfAbsent(rating.getUserId(), key -> new ArrayList<>()).add(rating);
        ratingsByImdbId.computeIfAbsent(rating.getImdbId(), key -> new ArrayList<>()).add(rating);
        return rating;
    }

    public List<Rating> findRatingsByUserId(String userId) {
        return new ArrayList<>(ratingsByUser.getOrDefault(userId, List.of()));
    }

    public Optional<Rating> findRatingByUserIdAndImdbId(String userId, String imdbId) {
        return ratingsByUser.getOrDefault(userId, List.of()).stream()
                .filter(rating -> imdbId.equals(rating.getImdbId()))
                .findFirst();
    }

    public Optional<Rating> findRatingById(String ratingId) {
        return Optional.ofNullable(ratingsById.get(ratingId));
    }

    public void deleteRating(String ratingId) {
        Rating rating = ratingsById.remove(ratingId);
        if (rating != null) {
            ratingsByUser.computeIfPresent(rating.getUserId(), (k, list) -> {
                list.removeIf(item -> ratingId.equals(item.getId()));
                return list;
            });
            ratingsByImdbId.computeIfPresent(rating.getImdbId(), (k, list) -> {
                list.removeIf(item -> ratingId.equals(item.getId()));
                return list;
            });
        }
    }

    public void deleteRatingByUserIdAndImdbId(String userId, String imdbId) {
        List<Rating> ratings = ratingsByUser.getOrDefault(userId, List.of());
        ratings.removeIf(rating -> imdbId.equals(rating.getImdbId()));
        ratingsByUser.put(userId, ratings);
        List<Rating> imdbRatings = ratingsByImdbId.getOrDefault(imdbId, List.of());
        imdbRatings.removeIf(rating -> userId.equals(rating.getUserId()));
        ratingsByImdbId.put(imdbId, imdbRatings);
    }

    public List<Rating> findRatingsByImdbId(String imdbId) {
        return new ArrayList<>(ratingsByImdbId.getOrDefault(imdbId, List.of()));
    }

    public long countRatingsByUserId(String userId) {
        return ratingsByUser.getOrDefault(userId, List.of()).size();
    }
}
