// ======================================================
// Movie Recommendation Platform - Main JavaScript
// ======================================================

document.addEventListener('DOMContentLoaded', function () {

    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.auto-dismiss');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.5s ease';
            setTimeout(function () { alert.remove(); }, 500);
        }, 5000);
    });

    // Star Rating interactive
    initStarRating();

    // Watchlist buttons
    initWatchlistButtons();

    // Image error fallback
    initImageFallback();

    // Tooltip init
    initTooltips();

    // Navbar active link
    setActiveNavLink();

    // Animate cards on scroll
    initScrollAnimation();
});

// ======================================================
// STAR RATING
// ======================================================
function initStarRating() {
    const starContainers = document.querySelectorAll('.star-rating');
    starContainers.forEach(function (container) {
        const inputs = container.querySelectorAll('input');
        const labels = container.querySelectorAll('label');

        labels.forEach(function (label) {
            label.addEventListener('mouseenter', function () {
                const forVal = this.getAttribute('for');
                const input = container.querySelector('#' + forVal);
                const val = parseInt(input.value);
                updateStars(labels, val);
            });
        });

        container.addEventListener('mouseleave', function () {
            const checked = container.querySelector('input:checked');
            if (checked) {
                updateStars(labels, parseInt(checked.value));
            } else {
                updateStars(labels, 0);
            }
        });

        inputs.forEach(function (input) {
            input.addEventListener('change', function () {
                updateStars(labels, parseInt(this.value));
                const display = document.getElementById('selectedStars');
                if (display) {
                    display.textContent = this.value + ' Star' + (this.value > 1 ? 's' : '');
                }
            });
        });
    });
}

function updateStars(labels, value) {
    labels.forEach(function (label) {
        const input = document.querySelector('#' + label.getAttribute('for'));
        if (input && parseInt(input.value) <= value) {
            label.style.color = '#f5c518';
        } else {
            label.style.color = '#2a2a2a';
        }
    });
}

// ======================================================
// WATCHLIST BUTTONS (AJAX)
// ======================================================
function initWatchlistButtons() {
    // Add to watchlist
    document.querySelectorAll('[data-watchlist-add]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            const data = {
                imdbId: this.dataset.imdbId,
                title: this.dataset.title,
                year: this.dataset.year,
                genre: this.dataset.genre,
                poster: this.dataset.poster,
                imdbRating: this.dataset.imdbRating,
                director: this.dataset.director
            };
            addToWatchlist(data, this);
        });
    });

    // Remove from watchlist
    document.querySelectorAll('[data-watchlist-remove]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            const imdbId = this.dataset.imdbId;
            removeFromWatchlist(imdbId, this);
        });
    });
}

function addToWatchlist(data, btn) {
    btn.disabled = true;
    btn.innerHTML = '<i class="bi bi-hourglass-split me-1"></i> Adding...';

    fetch('/watchlist/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': getCsrfToken()
        },
        body: JSON.stringify(data)
    })
    .then(function (res) { return res.json(); })
    .then(function (result) {
        if (result.success) {
            btn.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i> In Watchlist';
            btn.classList.add('added');
            btn.dataset.watchlistRemove = '';
            delete btn.dataset.watchlistAdd;
            showToast('Added to watchlist!', 'success');
        } else {
            btn.innerHTML = '<i class="bi bi-bookmark-plus me-1"></i> Watchlist';
            btn.disabled = false;
            showToast(result.message || 'Already in watchlist', 'info');
        }
    })
    .catch(function () {
        btn.innerHTML = '<i class="bi bi-bookmark-plus me-1"></i> Watchlist';
        btn.disabled = false;
        showToast('Failed to add to watchlist', 'error');
    });
}

function removeFromWatchlist(imdbId, btn) {
    if (!confirm('Remove this movie from your watchlist?')) return;

    btn.disabled = true;

    fetch('/watchlist/remove/' + imdbId, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': getCsrfToken()
        }
    })
    .then(function (res) { return res.json(); })
    .then(function (result) {
        if (result.success) {
            const card = btn.closest('.watchlist-item, .movie-card, [data-movie-card]');
            if (card) {
                card.style.transition = 'all 0.3s ease';
                card.style.opacity = '0';
                card.style.transform = 'scale(0.95)';
                setTimeout(function () { card.remove(); }, 300);
            }
            showToast('Removed from watchlist!', 'success');
        } else {
            btn.disabled = false;
            showToast(result.message || 'Failed to remove', 'error');
        }
    })
    .catch(function () {
        btn.disabled = false;
        showToast('Failed to remove from watchlist', 'error');
    });
}

// ======================================================
// CSRF TOKEN
// ======================================================
function getCsrfToken() {
    const meta = document.querySelector('meta[name="_csrf"]');
    return meta ? meta.getAttribute('content') : '';
}

// ======================================================
// TOAST NOTIFICATIONS
// ======================================================
function showToast(message, type) {
    const toastContainer = getOrCreateToastContainer();
    const toast = document.createElement('div');
    toast.className = 'toast-notification toast-' + type;

    const icons = {
        success: '<i class="bi bi-check-circle-fill"></i>',
        error: '<i class="bi bi-x-circle-fill"></i>',
        info: '<i class="bi bi-info-circle-fill"></i>',
        warning: '<i class="bi bi-exclamation-triangle-fill"></i>'
    };

    toast.innerHTML = (icons[type] || icons.info) + ' ' + message;

    const styles = {
        success: { bg: 'rgba(40,167,69,0.95)', border: '#28a745' },
        error: { bg: 'rgba(220,53,69,0.95)', border: '#dc3545' },
        info: { bg: 'rgba(23,162,184,0.95)', border: '#17a2b8' },
        warning: { bg: 'rgba(255,193,7,0.95)', border: '#ffc107' }
    };

    const style = styles[type] || styles.info;
    toast.style.cssText = `
        background: ${style.bg};
        border-left: 4px solid ${style.border};
        color: white;
        padding: 0.85rem 1.2rem;
        border-radius: 10px;
        margin-bottom: 0.6rem;
        display: flex;
        align-items: center;
        gap: 0.6rem;
        font-weight: 600;
        font-size: 0.9rem;
        box-shadow: 0 5px 20px rgba(0,0,0,0.4);
        opacity: 0;
        transform: translateX(100px);
        transition: all 0.3s ease;
        max-width: 320px;
    `;

    toastContainer.appendChild(toast);

    requestAnimationFrame(function () {
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(0)';
    });

    setTimeout(function () {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100px)';
        setTimeout(function () { toast.remove(); }, 300);
    }, 4000);
}

function getOrCreateToastContainer() {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        `;
        document.body.appendChild(container);
    }
    return container;
}

// ======================================================
// IMAGE FALLBACK
// ======================================================
function initImageFallback() {
    document.querySelectorAll('img[data-fallback]').forEach(function (img) {
        img.addEventListener('error', function () {
            this.src = this.dataset.fallback;
            this.removeEventListener('error', arguments.callee);
        });
    });

    document.querySelectorAll('.movie-img').forEach(function (img) {
        img.addEventListener('error', function () {
            const wrapper = this.closest('.movie-card-poster, .movie-poster-large');
            if (wrapper) {
                wrapper.innerHTML = `
                    <div class="no-poster-placeholder">
                        <i class="bi bi-film"></i>
                        <span>No Poster</span>
                    </div>
                `;
            }
        });
    });
}

// ======================================================
// TOOLTIPS
// ======================================================
function initTooltips() {
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltipTriggerList.forEach(function (el) {
            new bootstrap.Tooltip(el);
        });
    }
}

// ======================================================
// ACTIVE NAV LINK
// ======================================================
function setActiveNavLink() {
    const path = window.location.pathname;
    document.querySelectorAll('.navbar-nav-custom .nav-link').forEach(function (link) {
        const href = link.getAttribute('href');
        if (href && path.startsWith(href) && href !== '/') {
            link.classList.add('active');
        }
    });
}

// ======================================================
// SCROLL ANIMATION
// ======================================================
function initScrollAnimation() {
    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.animate-on-scroll').forEach(function (el) {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'all 0.5s ease';
        observer.observe(el);
    });
}

// ======================================================
// SEARCH FORM
// ======================================================
function submitSearch(event) {
    const input = document.getElementById('searchInput');
    if (!input || !input.value.trim()) {
        event.preventDefault();
        input.focus();
        return false;
    }
    return true;
}

// ======================================================
// CONFIRM DIALOG
// ======================================================
function confirmDelete(message) {
    return confirm(message || 'Are you sure you want to delete this?');
}

// ======================================================
// RATING FORM HELPER
// ======================================================
function validateRatingForm() {
    const checked = document.querySelector('.star-rating input:checked');
    if (!checked) {
        showToast('Please select a star rating', 'warning');
        return false;
    }
    return true;
}

// ======================================================
// TOGGLE PASSWORD VISIBILITY
// ======================================================
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = document.querySelector('[data-toggle-pw="' + inputId + '"] i');
    if (input) {
        if (input.type === 'password') {
            input.type = 'text';
            if (icon) icon.className = 'bi bi-eye-slash';
        } else {
            input.type = 'password';
            if (icon) icon.className = 'bi bi-eye';
        }
    }
}

// ======================================================
// SMOOTH SCROLL TO SECTION
// ======================================================
function scrollTo(elementId) {
    const el = document.getElementById(elementId);
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}
